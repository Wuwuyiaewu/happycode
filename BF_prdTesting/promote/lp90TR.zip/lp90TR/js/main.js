	var $GA_NAME='lp327A';
	$(document).ready(function(){ 
		$("#total_count_1").animateNumbers(count1, true, 500);
		$("#total_count_2").animateNumbers(count2, true, 500);	
		setTimeout(function() { 
			$.ajax({
				type:"GET",
				url: getUrl(),
				//dataType: 'jsonp',
				//jsonp:"callback",
				success:function(msg){
					setProduct(msg[0],1);
					setProduct(msg[1],2);
					setProduct(msg[2],3);


				}
			}).then(resp => {
			console.log(resp)
			}) ;	
		
		}, 1500);
	
		
		technicalAnalysisVue.isShowTechnicalAnalysisHtml=false;
		technicalAnalysisVue.title_content1='<img style="height: 0.5rem;" src="<!--#echo var='gwfx_m_cdn'-->/promote/lp327/images/big_title2.png">';
		technicalAnalysisVue.title_content2='<img style="height: 0.5rem;" src="<!--#echo var='gwfx_m_cdn'-->/promote/lp327/images/big_title3.png">';
		technicalAnalysisVue.rankedButtonPath="<!--#echo var='gwfx_m_cdn'-->/promote/lp327/images/r_btn.png";
		technicalAnalysisVue.more_btn_text='下载APP了解更多';	
		
	}) ;

	technicalAnalysisVue.lpToH5PageChecking= function(urlPath) {
			gotoRegister();
			_gaq.push(['_trackEvent', $GA_NAME, 'register', 'content_ti', 1, true]);
	}

	
	function setProduct(data,rank){
		let html='';
		let direction=data.direction=='0'?'多':'空';
		html='<td><span>'+data.name+'</span></td><td><span>'+direction+'</span></td><td><span>'+data.enterPrice+'</span></td><td><span>'+data.targetPrice+'</span></td><td><span>'+data.profit+'</span></td>';
		console.log(html);
		$("#rank_"+rank+"_product").html(html);
	}
	
	function getUrl(){
		 return mis_api_url+'/h5Api/promotion/showProductYesterdayProfit.do';	
		
	}
	
	function gotoInnerAboutUsPage(page){
		if (window.location.search==null || window.location.search==''){
			window.location.href="<!--#echo var='gwfx_pc'-->/03-App-lp/H5TradeInfo.html?page="+page;
		}
		else {
			window.location.href="<!--#echo var='gwfx_pc'-->/03-App-lp/H5TradeInfo.html"+window.location.search+'&page='+page;
		}
	}
	
	function downloadApp(){
		window.open('https://m.zhixuan6868.com/common/03-app-lp327a.html','_blank');
	}

	technicalAnalysisVue.moreBtnClick=function(){
		downloadApp();
		_gaq.push(['_trackEvent',$GA_NAME,'download', 'ti', 1,true]);
	}
	

